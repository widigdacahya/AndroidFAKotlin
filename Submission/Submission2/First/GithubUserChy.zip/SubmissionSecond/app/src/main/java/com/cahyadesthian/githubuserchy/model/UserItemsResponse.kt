package com.cahyadesthian.githubuserchy.model

data class UserItemsResponse(
    val login: String,
    val avatar_url : String
)
