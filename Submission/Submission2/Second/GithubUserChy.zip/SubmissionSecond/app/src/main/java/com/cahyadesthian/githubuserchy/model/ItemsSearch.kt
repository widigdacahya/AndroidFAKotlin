package com.cahyadesthian.githubuserchy.model

data class ItemsSearch(
    val items : ArrayList<UserItemsResponse>
)
